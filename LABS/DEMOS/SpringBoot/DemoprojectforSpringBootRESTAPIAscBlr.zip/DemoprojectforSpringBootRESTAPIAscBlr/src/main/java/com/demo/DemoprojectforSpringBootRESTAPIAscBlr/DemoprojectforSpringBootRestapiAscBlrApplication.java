package com.demo.DemoprojectforSpringBootRESTAPIAscBlr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoprojectforSpringBootRestapiAscBlrApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoprojectforSpringBootRestapiAscBlrApplication.class, args);
	}

}
