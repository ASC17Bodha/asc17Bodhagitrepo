package com.demo.DemoprojectforSpringBootRESTAPIAscBlr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoprojectforSpringBootRestapiAscBlrApplicationTests {

	@Test
	void contextLoads() {
	}

}
